CREATE DATABASE  IF NOT EXISTS `sortation` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `sortation`;
-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: 192.168.199.18    Database: sortation
-- ------------------------------------------------------
-- Server version	5.7.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `disk_lookup`
--

DROP TABLE IF EXISTS `disk_lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `disk_lookup` (
  `message_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `admissibility` varchar(1) DEFAULT NULL,
  `data_entry` varchar(1) DEFAULT NULL,
  `hazmat_com1` varchar(1) DEFAULT NULL,
  `hazmat_com2` varchar(1) DEFAULT NULL,
  `hazmat_com3` varchar(1) DEFAULT NULL,
  `alcohol_flag` varchar(3) DEFAULT NULL,
  `at_gatway` varchar(1) DEFAULT NULL,
  `broker_release` varchar(1) DEFAULT NULL,
  `carrier` varchar(4) DEFAULT NULL,
  `country_code` bigint(20) DEFAULT NULL,
  `data_flag` varchar(1) DEFAULT NULL,
  `days_late` varchar(1) DEFAULT NULL,
  `delcon_flag` varchar(1) DEFAULT NULL,
  `delete_flag` varchar(1) DEFAULT NULL,
  `desthub_flag` varchar(1) DEFAULT NULL,
  `dstrm_alt` bigint(20) DEFAULT NULL,
  `dstrm_gnd` bigint(20) DEFAULT NULL,
  `dstrm_res` bigint(20) DEFAULT NULL,
  `dstrm_x` bigint(20) DEFAULT NULL,
  `dstrm_y` bigint(20) DEFAULT NULL,
  `dstrm_z` bigint(20) DEFAULT NULL,
  `essd` bigint(20) DEFAULT NULL,
  `esst` bigint(20) DEFAULT NULL,
  `excpt_flag` varchar(3) DEFAULT NULL,
  `go_no_go_flag` varchar(1) DEFAULT NULL,
  `hazmat_flag` varchar(1) DEFAULT NULL,
  `hold_flag` varchar(1) DEFAULT NULL,
  `image_flag` varchar(1) DEFAULT NULL,
  `intercept_flag` varchar(1) DEFAULT NULL,
  `international_flag` varchar(1) DEFAULT NULL,
  `lane_gnd` varchar(5) DEFAULT NULL,
  `lane_res` varchar(5) DEFAULT NULL,
  `lane_x` varchar(5) DEFAULT NULL,
  `lane_y` varchar(5) DEFAULT NULL,
  `lane_z` varchar(5) DEFAULT NULL,
  `message_type` varchar(255) DEFAULT NULL,
  `mkt_type` varchar(5) DEFAULT NULL,
  `n_of_x` bigint(20) DEFAULT NULL,
  `opf_date` bigint(20) DEFAULT NULL,
  `origin_term` bigint(20) DEFAULT NULL,
  `pickup_date` bigint(20) DEFAULT NULL,
  `pkg_count` bigint(20) DEFAULT NULL,
  `powder_type` varchar(1) DEFAULT NULL,
  `process_id` bigint(20) DEFAULT NULL,
  `recipient_id` varchar(32) DEFAULT NULL,
  `scan_device` varchar(255) DEFAULT NULL,
  `sch_del_date` bigint(20) DEFAULT NULL,
  `sending_app` varchar(255) DEFAULT NULL,
  `shipment_id` varchar(30) DEFAULT NULL,
  `shipper_num` bigint(20) DEFAULT NULL,
  `snap_flag` varchar(1) DEFAULT NULL,
  `sort_status` varchar(1) DEFAULT NULL,
  `sort_time_exp` varchar(1) DEFAULT NULL,
  `state_name` varchar(2) DEFAULT NULL,
  `status` varchar(1) DEFAULT NULL,
  `stop_id` varchar(32) DEFAULT NULL,
  `svc_code` varchar(3) DEFAULT NULL,
  `svc_type` varchar(5) DEFAULT NULL,
  `swak_cntl` varchar(2) DEFAULT NULL,
  `swak_date` bigint(20) DEFAULT NULL,
  `swak_station` varchar(1) DEFAULT NULL,
  `swak_terminal` bigint(20) DEFAULT NULL,
  `swak_time` bigint(20) DEFAULT NULL,
  `track1` varchar(34) DEFAULT NULL,
  `track1_file_no` bigint(20) DEFAULT NULL,
  `track2` varchar(34) DEFAULT NULL,
  `track2_file_no` bigint(20) DEFAULT NULL,
  `track3` varchar(34) DEFAULT NULL,
  `trackid` varchar(20) DEFAULT NULL,
  `validitx` varchar(3) DEFAULT NULL,
  `validity` varchar(1) DEFAULT NULL,
  `video_code` varchar(2) DEFAULT NULL,
  `weight` bigint(20) DEFAULT NULL,
  `zipcode` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`message_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9223372036854775807 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disk_lookup`
--

LOCK TABLES `disk_lookup` WRITE;
/*!40000 ALTER TABLE `disk_lookup` DISABLE KEYS */;
INSERT INTO `disk_lookup` VALUES (9612804126325465,'1','1','1','1','1','Yes','1','1','Yes',98,'1','0','0','1','0',1,1,1,1,1,1,1,1,'0','1','1','1','1','1','0',NULL,NULL,NULL,NULL,NULL,'0','1',1,NULL,0,0,0,'0',0,'1','2',2,'3','3',4,'5','4','4','1','1','1','1','1','1',0,'4',4,0,'9612804126325465',NULL,'9612804126325465533749',NULL,'96128041263254655337410','123456','0','1','1',1,'8064'),(9612895040686074,'1','1','1','1','1','YEs','1','1','Yes',98,'1','0','0','1','0',1,1,1,1,1,1,1,1,'0','1','1','1','1','1','0',NULL,NULL,NULL,NULL,NULL,'0','1',1,NULL,0,0,0,'0',0,'1','2',2,'3','3',4,'5','4','4','1','1','1','1','1','1',0,'4',4,0,'9612895040686070248504',0,'9612895040686070248506',NULL,'9612895040686070248506','1354878','0','1','1',1,'0041'),(96120180685683001,'1','1','1','1','1','YEs','1','1','Yes',98,'1','0','0','1','0',1,1,1,1,1,1,1,1,'0','1','1','1','1','1','0',NULL,NULL,NULL,NULL,NULL,'0','1',1,NULL,0,0,0,'0',0,'1','2',2,'3','3',4,'5','4','4','1','1','1','1','1','1',0,'4',4,0,'9612018068568300193500',0,'9612018068568300193501',NULL,'9612018068568300193502','1354878','0','1','1',1,'0011'),(961201922578609284,'1','1','1','1','1','YEs','1','1','Yes',98,'1','0','0','1','0',1,1,1,1,1,1,1,1,'0','1','1','1','1','1','0',NULL,NULL,NULL,NULL,NULL,'0','1',1,NULL,0,0,0,'0',0,'1','2',2,'3','3',4,'5','4','4','1','1','1','1','1','1',0,'4',4,0,'9612019225786092849600',0,'9612019225786092849601',NULL,'9612019225786092849602','1354878','0','1','1',1,'0061'),(9223372036854775807,'1','1','1','1','1','YEs','1','1','Yes',98,'1','0','0','1','0',1,1,1,1,1,1,1,1,'0','1','1','1','1','1','0',NULL,NULL,NULL,NULL,NULL,'0','1',1,NULL,0,0,0,'0',0,'1','2',2,'3','3',4,'5','4','4','1','1','1','1','1','1',0,'4',4,0,'9611019674668201240800',0,'9611019674668201240801',NULL,'9611019674668201240802','1354878','0','1','1',1,'0027');
/*!40000 ALTER TABLE `disk_lookup` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-19 20:51:28
